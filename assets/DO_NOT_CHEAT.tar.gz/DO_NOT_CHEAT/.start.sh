#!/bin/bash
chmod -r GAME_OF_THRONES/HOUSE\ TARGARION/.readme7
echo "done"
rm .start.sh
exec bash
